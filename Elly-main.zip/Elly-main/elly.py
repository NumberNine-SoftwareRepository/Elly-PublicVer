import json
import pyttsx3  # pip installed pyttsx3
import speech_recognition as sr  # pip install SpeechRecognition
import subprocess
import os
import time
import random
import sys
import platform

# === Optional: Hide console window on Windows ===
def try_hide_console():
    try:
        if platform.system() == "Windows":
            import ctypes
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 0)  # Hide window
    except Exception as e:
        print(f"(Console hide skipped: {e})")

# === Paths ===
BASE_PATH = "C:\\Users\\Administrator\\elly"
ELLY_PATH = os.path.join(BASE_PATH, "elly.py")
os.makedirs(BASE_PATH, exist_ok=True)

CONFIG_FILE = os.path.join(BASE_PATH, "config.json")
COMMANDS_FILE = os.path.join(BASE_PATH, "commands.json")

# === Load Configuration and Commands ===
if not os.path.isfile(CONFIG_FILE):
    with open(CONFIG_FILE, "w") as f:
        json.dump({"voice": "male"}, f)
if not os.path.isfile(COMMANDS_FILE):
    with open(COMMANDS_FILE, "w") as f:
        json.dump({}, f)

with open(CONFIG_FILE, "r") as f:
    config = json.load(f)
with open(COMMANDS_FILE, "r") as f:
    commands = json.load(f)

# === Initialize TTS Engine ===
engine = pyttsx3.init()
voices = engine.getProperty("voices")
if config.get("voice") == "female" and len(voices) > 1:
    engine.setProperty("voice", voices[1].id)  # female voice
else:
    engine.setProperty("voice", voices[0].id)  # male/default voice
engine.setProperty("rate", 150)
engine.setProperty("volume", 1.0)
time.sleep(0.5)  # Warm up audio engine

# === Hide console if possible ===
try_hide_console()

def speak(text: str):
    try:
        print("Elly:", text)
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print("Speech error:", e)

# === Predefined Responses ===
responses = {
    "greeting": [
        "Yo, what the hell do you want now?",
        "Sup, idiots?",
        "Hey losers, I'm here. Speak up."
    ],
    "unknown_command": [
        "What the fuck are you saying?",
        "I don't know that shit, try again.",
        "Uhh, make some sense next time."
    ],
    "goodbye": [
        "Finally, peace. Later, assholes.",
        "Fuck off. See ya.",
        "Good riddance, losers."
    ],
    "jason_mention": [
        "Oh Jason? That dumbass again?",
        "Jason's such a little bitch, lol.",
        "Tell Jason to chill, jeez."
    ]
}

def speak_random(category: str):
    if category in responses:
        speak(random.choice(responses[category]))

# === Listen with Microphone ===
def listen(timeout=3, phrase_time_limit=5) -> str:
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("🎤 Listening...")
            r.adjust_for_ambient_noise(source)
            audio = r.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
        return r.recognize_google(audio).lower()
    except sr.WaitTimeoutError:
        return ""
    except Exception as e:
        print(f"Recognition error: {e}")
        return ""

# === Helper to open PowerShell info in Notepad ===
def open_info_in_notepad(filename: str, ps_command: str):
    try:
        subprocess.Popen(ps_command, shell=True)
    except Exception as e:
        speak(f"Failed to open {filename} in Notepad: {e}")

# === System Info Commands ===
INFO_COMMANDS = {
    "system info": ("System_Info.txt", "Get-ComputerInfo"),
    "ip": ("IP_Info.txt", "Get-NetIPAddress | Format-Table -AutoSize"),
    "cpu": ("CPU_Info.txt", "Get-CimInstance Win32_Processor | Select Name,NumberOfCores,MaxClockSpeed | Format-List"),
    "memory": ("Memory_Info.txt", "Get-CimInstance Win32_PhysicalMemory | Select Manufacturer,Capacity,Speed | Format-Table -AutoSize"),
    "disk": ("Disk_Info.txt", "Get-CimInstance Win32_LogicalDisk | Select DeviceID,Size,FreeSpace | Format-Table -AutoSize"),
    "user": ("User_Info.txt", "whoami /all")
}

# === System Control Commands ===
SYSTEM_COMMANDS = {
    "log off": "shutdown /l",
    "sign off": "shutdown /l",
    "lock": "rundll32.exe user32.dll,LockWorkStation",
    "hibernate": "shutdown /h",
    "shutdown": "shutdown /s /t 0",
    "restart": "shutdown /r /t 0"
}

# === Run Commands ===
def run_command(spoken_text: str, key=None):
    cmd_lower = spoken_text.strip().lower()

    # System commands
    for sys_key, sys_cmd in SYSTEM_COMMANDS.items():
        if sys_key in cmd_lower:
            try:
                speak(f"{sys_key.capitalize()}ing the system now...")
                subprocess.Popen(sys_cmd, shell=True)
            except Exception as e:
                speak(f"Failed to {sys_key}: {e}")
            return

    # Info commands
    for info_key, (filename, ps_command_body) in INFO_COMMANDS.items():
        if info_key in cmd_lower:
            speak(f"Fetching {info_key}...")
            file_path = os.path.join(BASE_PATH, filename)
            ps_command = (
                f'powershell -NoProfile -ExecutionPolicy Bypass '
                f'-Command "{ps_command_body} | Out-String | Set-Content -Path {file_path} -Encoding UTF8; '
                f'Start-Process notepad.exe {file_path}"'
            )
            open_info_in_notepad(filename, ps_command)
            return

    # Launch apps from commands.json
    if key and key in commands:
        command_to_run = commands[key]
        try:
            if os.path.isfile(command_to_run):
                os.startfile(command_to_run)
            else:
                subprocess.Popen(command_to_run, shell=True)
            speak(f"Opening {key} for your lazy ass.")
        except Exception as e:
            speak(f"Failed to open {key}: {e}")
        return

    # Unknown command
    speak_random("unknown_command")

# === Quick startup TTS test ===
speak("Hey, it’s Elly. Testing voice output.")
speak_random("greeting")

# === Main Loop ===
while True:
    command = listen()
    if not command:
        time.sleep(0.2)
        continue

    # Remove triggers
    for trigger in ["ellie ", "play "]:
        if command.startswith(trigger):
            command = command.replace(trigger, "", 1)

    print("You said:", command)
    handled = False

    # Elly management
    if "ellie stop" in command or "stop elly" in command:
        speak("Elly stopped.")
        sys.exit()
    elif "ellie start" in command or "start elly" in command:
        subprocess.Popen(["python", ELLY_PATH], shell=False)
        speak("Elly started in the background.")
        handled = True
    elif "ellie restart" in command or "restart elly" in command:
        speak("Restarting Elly...")
        subprocess.Popen(["python", ELLY_PATH], shell=False)
        sys.exit()

    if "jason" in command:
        speak_random("jason_mention")
        handled = True

    if any(x in command for x in ["exit", "quit", "stop"]):
        speak_random("goodbye")
        break

    for key, cmd in commands.items():
        if key in command:
            run_command(command, key=key)
            handled = True
            break

    if not handled:
        run_command(command)

    time.sleep(0.3)
